import { pgTable, text, serial, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Minimal schema — this app is primarily frontend-driven.
// Tools run calculations client-side; the backend is only used
// if we later add saved configurations or reference data APIs.

export const toolConfigs = pgTable("tool_configs", {
  id: serial("id").primaryKey(),
  toolId: text("tool_id").notNull(),
  name: text("name").notNull(),
  config: text("config").notNull(), // JSON string of saved parameters
});

export const insertToolConfigSchema = createInsertSchema(toolConfigs).omit({ id: true });
export type InsertToolConfig = z.infer<typeof insertToolConfigSchema>;
export type ToolConfig = typeof toolConfigs.$inferSelect;
